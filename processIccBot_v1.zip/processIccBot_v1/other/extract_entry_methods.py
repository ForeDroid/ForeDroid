import re
import pandas as pd
from collections import Counter

def extract_method_name(full_signature):
    """
    从形如 <com.mobimento.caponate.CapoNormalActivity: void onBackPressed()>
    的字符串中，仅提取方法名 (如 onBackPressed)。
    如果格式不符合预期，则直接返回原字符串或根据需求处理。
    """
    if not isinstance(full_signature, str):
        return ''  # 处理空值或非字符串的情况
    
    full_signature = full_signature.strip()
    # 利用正则表达式捕获方法名
    pattern = r'<[^:]+:\s*[^ ]+\s+([^(]+)\('
    match = re.match(pattern, full_signature)
    if match:
        return match.group(1).strip()
    else:
        return full_signature


def process_csv(
    input_csv_path,
    # entry_method 相关输出
    output_csv_methods,
    output_csv_methods_counts,
    # entry_point 相关输出
    output_csv_entry_points,
    output_csv_entry_points_counts,
    # entry_point_actions 相关输出
    output_csv_actions,
    output_csv_actions_counts
):
    # 读取 CSV
    df = pd.read_csv(input_csv_path, encoding='utf-8')

    # 确保存在相关列
    required_cols = ['entry_method', 'entry_point', 'entry_point_actions']
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"在 {input_csv_path} 中未找到 '{col}' 列，请检查列名。")

    # (1) 处理 entry_method
    df['entry_method'] = df['entry_method'].apply(extract_method_name)
    # 1.1) 获取所有不重复的 entry_method 并输出
    unique_methods = df['entry_method'].dropna().unique()
    pd.DataFrame(unique_methods, columns=['entry_method']).to_csv(
        output_csv_methods, index=False, encoding='utf-8'
    )
    # 1.2) 统计每个方法出现次数，并输出
    method_counts = df['entry_method'].value_counts().reset_index()
    method_counts.columns = ['entry_method', 'count']
    method_counts.to_csv(output_csv_methods_counts, index=False, encoding='utf-8')

    # (2) 处理 entry_point
    # 2.1) 获取所有不重复的 entry_point 并输出
    unique_entry_points = df['entry_point'].dropna().unique()
    pd.DataFrame(unique_entry_points, columns=['entry_point']).to_csv(
        output_csv_entry_points, index=False, encoding='utf-8'
    )
    # 2.2) 统计每个 entry_point 出现次数，并输出
    entry_point_counts = df['entry_point'].value_counts().reset_index()
    entry_point_counts.columns = ['entry_point', 'count']
    entry_point_counts.to_csv(output_csv_entry_points_counts, index=False, encoding='utf-8')

    # (3) 处理 entry_point_actions
    # 假设每行是以逗号分隔的动作，如 "ACTION_VIEW, ACTION_EDIT"
    # 3.1) 将所有行拆分后汇总到一个列表
    all_actions = []
    for actions_str in df['entry_point_actions'].dropna():
        # 以逗号分隔，并去除前后空格
        actions = [x.strip() for x in actions_str.split(',') if x.strip()]
        all_actions.extend(actions)

    # 3.2) 不重复的动作
    unique_actions = sorted(list(set(all_actions)))
    pd.DataFrame(unique_actions, columns=['entry_point_action']).to_csv(
        output_csv_actions, index=False, encoding='utf-8'
    )

    # 3.3) 动作出现次数
    counter = Counter(all_actions)
    actions_counts_df = pd.DataFrame(counter.items(), columns=['entry_point_action', 'count'])
    # 按出现次数从大到小排序
    actions_counts_df.sort_values('count', ascending=False, inplace=True)
    actions_counts_df.to_csv(output_csv_actions_counts, index=False, encoding='utf-8')

    print("===== 处理完成 =====")
    print(f"去重后的 entry_method 方法名输出到: {output_csv_methods}")
    print(f"entry_method 出现次数统计输出到: {output_csv_methods_counts}")
    print(f"去重后的 entry_point 输出到: {output_csv_entry_points}")
    print(f"entry_point 出现次数统计输出到: {output_csv_entry_points_counts}")
    print(f"去重后的 entry_point_actions 输出到: {output_csv_actions}")
    print(f"entry_point_actions 出现次数统计输出到: {output_csv_actions_counts}")


if __name__ == "__main__":
    # 输入 CSV 以及输出 CSV 的路径
    input_csv = './data/all_apks_combined_merged_id.csv'  # 替换为上一步生成的CSV路径

    # 1) entry_method 相关输出
    output_csv_methods = './data/unique_entry_methods.csv'
    output_csv_methods_counts = './data/entry_method_counts.csv'

    # 2) entry_point 相关输出
    output_csv_entry_points = './data/unique_entry_points.csv'
    output_csv_entry_points_counts = './data/entry_point_counts.csv'

    # 3) entry_point_actions 相关输出
    output_csv_actions = './data/unique_entry_point_actions.csv'
    output_csv_actions_counts = './data/entry_point_actions_counts.csv'

    process_csv(
        input_csv,
        output_csv_methods,
        output_csv_methods_counts,
        output_csv_entry_points,
        output_csv_entry_points_counts,
        output_csv_actions,
        output_csv_actions_counts
    )

