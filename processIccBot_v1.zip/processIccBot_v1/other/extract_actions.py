import pandas as pd

# 读取CSV文件
csv_file = 'data/all_apks_combined_merged_filtered_action.csv'  # 请将'your_file.csv'替换为您的CSV文件路径
df = pd.read_csv(csv_file)

# 检查'entry_point_actions'列是否存在
if 'entry_point_actions' not in df.columns:
    raise ValueError("CSV文件中未找到 'entry_point_actions' 列。请检查列名是否正确。")

# 提取'entry_point_actions'列，并处理缺失值
actions_series = df['entry_point_actions'].dropna()

# 假设每个单元格中的动作是以逗号分隔的
# 根据您的实际分隔符（如分号、空格等）调整split()中的参数
actions = actions_series.str.split(',').explode().str.strip()

# 获取唯一的动作
unique_actions = actions.unique()

# 将结果保存到新的CSV文件或打印出来
# 保存到CSV
pd.DataFrame(unique_actions, columns=['unique_actions']).to_csv('unique_actions2.csv', index=False)

# 或者打印结果
print("所有唯一的动作如下：")
for action in unique_actions:
    print(action)
