import json
import pandas as pd

def json_to_csv_pandas(input_json_path, output_csv_path):
    # 读取 JSON 数据
    with open(input_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    records = []
    
    # 遍历每个规则对象
    for item in data:
        findings = item.get('findings', [])
        if len(findings) < 2:
            continue  # 跳过不符合结构的项
        
        # 提取 sapcg_file 和 sensitiveAPI
        sapcg_info_list = findings[0]
        if not sapcg_info_list:
            continue  # 跳过缺少 sapcg_info 的项
        sapcg_info = sapcg_info_list[0]
        sapcg_file = sapcg_info.get('sapcg_file', '')
        sensitiveAPI = sapcg_info.get('sensitiveAPI', '')
        
        # 提取 call_chain 和 entry_point_actions
        call_chain_list = findings[1]
        for call_entry in call_chain_list:
            # 1.1
            call_chain = call_entry.get('call_chain', '')
            call_chain_str = " -> ".join(call_chain)  # 以 '->' 分隔
            
            entry_point_total = call_entry.get('entry_point', {})
            # entry_point, action, origin_entry_point, origin_actions, origin_call_chain
            
            # 1.2
            entry_point = entry_point_total.get('entry_point', '')
            # 1.3
            actions = entry_point_total.get('actions', '')
            actions_str = ", ".join(actions)  # 以逗号分隔
            # 1.4
            origin_entry_point = entry_point_total.get('origin_entry_point', '')
            # 1.5
            origin_actions = entry_point_total.get('origin_actions', '')
            origin_actions_str = ", ".join(origin_actions)  # 以逗号分隔
            # 1.6
            origin_call_chain = entry_point_total.get('origin_call_chain', '')
            origin_call_chain_str = "-> ".join(origin_call_chain)  # 以 '->'分隔
            

            
            # 提取 rule 信息
            # rule = item.get('rule', {})
            # or_predicates = rule.get('or_predicates', [])
            # or_predicates_str = ", ".join(or_predicates)
            # tags = rule.get('tags', [])
            # tags_str = ", ".join(tags)
            # rule_title = rule.get('title', '')
            # rule_description = rule.get('description', '')
            # rule_name = rule.get('name', '')
            
            # 添加记录
            record = {
                'sapcg_file': sapcg_file,
                'sensitiveAPI': sensitiveAPI,
                'call_chain': call_chain_str,
                'entry_point' : entry_point,
                'entry_point_actions': actions_str,
                'origin_entry_point' : origin_entry_point,
                'origin_entry_point_actions': origin_actions_str,
                'origin_call_chain': origin_call_chain_str,
                # 'rule_or_predicates': or_predicates_str,
                # 'rule_tags': tags_str,
                # 'rule_title': rule_title,
                # 'rule_description': rule_description,
                # 'rule_name': rule_name
            }
            records.append(record)
    
    # 创建 DataFrame 并导出为 CSV
    df = pd.DataFrame(records, columns=[
        'sapcg_file',
        'sensitiveAPI',
        'call_chain',
        'entry_point',
        'entry_point_actions',
        'origin_entry_point' ,
        'origin_entry_point_actions',
        'origin_call_chain',
        # 'rule_or_predicates',
        # 'rule_tags',
        # 'rule_title',
        # 'rule_description',
        # 'rule_name'
    ])
    
    df.to_csv(output_csv_path, index=False, encoding='utf-8')
    print(f"转换完成，输出文件位于：{output_csv_path}")

if __name__ == "__main__":
    # 输入和输出文件路径
    input_json_path = '/home/ming/work/iccbot/ICCBot/output/output/acecard/CallGraphInfo/rule_analysis_report.json'  # 替换为你的 JSON 文件路径
    output_csv_path = './data/acecard.csv'  # 替换为你希望的 CSV 输出路径
    
    json_to_csv_pandas(input_json_path, output_csv_path)
