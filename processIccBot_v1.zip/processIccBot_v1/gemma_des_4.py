

        # api_key="sk-7N9BefzTpWLzn5B8PeZIKsUxpSLgm1MR22pyjTzOl1OV43h6",

import pandas as pd
from openai import OpenAI
import time
import os

def process_call_chains(input_csv_path, output_csv_path, max_retries=5, retry_delay=2, pause_duration = 3600):
    """Process API call chains and generate descriptions using OpenAI API with retry on failure."""
    # 初始化 OpenAI 客户端
    client = OpenAI(
        api_key="sk-K11daAAbE6FaOiqJPpRnqLlweq2PhFRqtk5hMovvGCGPwtUM",
        base_url="https://api.agicto.cn/v1"
    )
    
    client2 = OpenAI(
        api_key="sk-j53mESJ888le3I4BWnLo2SaJ3M3Od27YvikyzCWFKNRN4Vf2",
        base_url="https://api.agicto.cn/v1"
    )
    
    # 读取输入 CSV 文件
    df = pd.read_csv(input_csv_path)
    
    # 添加一个新的列用于生成的描述
    df["generated_description"] = None
    count = 0
    model_count = 0
    
    # 检查输出文件是否存在，以决定是否写入表头
    output_file_exists = os.path.isfile(output_csv_path)
    
    # 迭代 DataFrame 中的每一行
    for index, row in df.iterrows():
        call_chain = row["call_chain"]  # 提取调用链
        apk_name = row["apk_name"]      # 提取 APK 名称
        row_id = row["id"]              # 提取行 ID
        if row_id < 801:
            continue
        
        # 构建提示语
        prompt = (
            "Please generate a short and concise behavior description based on the following API call chain. "
            "The description should primarily use nouns and verbs, maintaining consistent formatting and terminology.\n\n"
            "To ensure the generated description is suitable for subsequent semantic similarity calculations, it is recommended to:\n\n"
            "- **Keep it concise and clear**: The description should be as brief as possible, highlighting key operations, and avoiding lengthy and complex sentence structures.\n"
            "- **Synthesize related functions**: Combine the functionalities of related functions to avoid repetitive or redundant descriptions.\n\n"
            "Do not use line breaks in your response; provide only the behavior description."
        )
        question = f"API call chain:\n{call_chain}"
        
        # if count % 10 == 0:
        combined_question = prompt + "\n" + question
        
        # 打印当前处理的调用链
        print(f"Processing call chain: {call_chain}")
        
        attempt = 0
        success = False
        response = ""
        change_model = False
        change_client = False
        
        
        while attempt < max_retries and not success:
            try:
                # 创建聊天完成请求
                if(not change_model and not change_client and model_count==0):
                    chat_completion = client.chat.completions.create(
                        messages=[
                            {
                                "role": "user",
                                "content": combined_question,
                            }
                        ],
                        # model="gemma2-9b-it",
                        model="llama3-70b-8192"
                    )
                # elif(change_client and not change_model):  
                #     chat_completion = client2.chat.completions.create(
                #         messages=[
                #             {
                #                 "role": "user",
                #                 "content": combined_question,
                #             }
                #         ],
                #         model="gemma2-9b-it",
                #         # model="llama3-70b-8192"
                #     )
                else:
                    chat_completion = client.chat.completions.create(
                        messages=[
                            {
                                "role": "user",
                                "content": combined_question,
                            }
                        ],
                        # model="gemma2-9b-it",
                        model="llama3-70b-8192"
                    )
                    model_count = model_count - 1
                    
                
                # 获取响应内容
                response = chat_completion.choices[0].message.content.strip()
                response = " ".join(response.splitlines())  # 移除所有换行符
                if ":" in response:
                    response = response.split(":", 1)[1].strip()
                
                if response and response != "Description generation failed":
                    success = True
                else:
                    raise ValueError("Invalid response received from API.")
            
            except Exception as e:
                attempt += 1
                if attempt < max_retries:
                    print(f"Attempt {attempt} failed for APK: {apk_name}, ID: {row_id}. Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    if(not change_model and change_client):
                        attempt = 0
                        change_model = 1
                        model_count = 100
                    elif(not change_model and not change_client):
                        attempt = 0
                        change_client = 1
                        model_count = 100
                    else:
                        print(f"Attempt {attempt} failed for APK: {apk_name}, ID: {row_id}. Pausing for {pause_duration} seconds before retrying...")
                        time.sleep(pause_duration)
                        attempt = 0
                        model_count = 0
                        
                    print(f"Error: Failed to generate description for APK: {apk_name}, ID: {row_id} after {max_retries} attempts. Error: {e}")
        
        if success:
            # 保存生成的描述
            row_to_append = {
                "call_chain": call_chain,
                "generated_description": response,
                "id": row_id
            }
            pd.DataFrame([row_to_append]).to_csv(
                output_csv_path,
                header=not output_file_exists,
                index=False,
                mode='a',
                encoding="utf-8"
            )
            if not output_file_exists:
                output_file_exists = True  # 表头已经写入
            print(f"Appended response for APK: {apk_name}, ID: {row_id}")
            count += 1
        else:
            # 保存失败的描述
            row_to_append = {
                "call_chain": call_chain,
                "generated_description": "Description generation failed",
                "id": row_id
            }
            pd.DataFrame([row_to_append]).to_csv(
                output_csv_path,
                header=not output_file_exists,
                index=False,
                mode='a',
                encoding="utf-8"
            )
            if not output_file_exists:
                output_file_exists = True  # 表头已经写入
            print(f"Error: Failed to generate description for APK: {apk_name}, ID: {row_id}")
    
    print("All call chains have been processed!")



if __name__ == "__main__":
    INPUT_CSV_PATH = "./data/all_apks_combined_merged_id.csv"  # Input CSV file path
    OUTPUT_CSV_PATH = "./data/with_descriptions_gemma.csv"        # Output CSV file path
    
    try:
        # save_questions_and_answers_to_csv_with_pandas(driver, "./data/descriptions_from_web")
        process_call_chains(INPUT_CSV_PATH, OUTPUT_CSV_PATH)  # Batch process call chains
    finally:
        print("All processing completed. Exiting the program.")
