import os
import json
import pandas as pd


def process_all_apk_folders(input_root_folder, output_csv_path):
    records = []

    # 遍历 GPmalware 文件夹下的每个 APK 文件夹
    for apk_folder in os.listdir(input_root_folder):
        apk_folder_path = os.path.join(input_root_folder, apk_folder)
        # 检查是否为文件夹
        if not os.path.isdir(apk_folder_path):
            continue

        # 定位 rule_analysis_report.json 文件
        json_file_path = os.path.join(apk_folder_path, "CallGraphInfo", "rule_analysis_report.json")
        if not os.path.exists(json_file_path):
            print(f"文件 {json_file_path} 不存在，跳过 {apk_folder}")
            continue

        # 读取 JSON 数据
        with open(json_file_path, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                print(f"解析 JSON 文件失败：{json_file_path}")
                continue
        
        # 解析 JSON 并生成记录
        for item in data:
            findings = item.get('findings', [])
            if len(findings) < 2:
                continue  # 跳过不符合结构的项
            
            # 提取 sapcg_file 和 sensitiveAPI
            sapcg_info_list = findings[0]
            if not sapcg_info_list:
                continue  # 跳过缺少 sapcg_info 的项
            sapcg_info = sapcg_info_list[0]
            sapcg_file = sapcg_info.get('sapcg_file', '')
            sensitiveAPI = sapcg_info.get('sensitiveAPI', '')
            
            # 提取 call_chain 和 entry_point_actions
            call_chain_list = findings[1]
            for call_entry in call_chain_list:
                # 提取 call_chain 信息
                call_chain = call_entry.get('call_chain', [])
                call_chain_str = " -> ".join(call_chain)  # 以 '->' 分隔
                entry_method = call_chain[0] if call_chain else ''  # 新增：获取 call_chain 的第一个元素

                # 提取 entry_point 相关信息
                entry_point_total = call_entry.get('entry_point', {})
                entry_point = entry_point_total.get('entry_point', '')
                actions = entry_point_total.get('actions', [])
                actions_str = ", ".join(actions)  # 以逗号分隔
                origin_entry_point = entry_point_total.get('origin_entry_point', '')
                origin_actions = entry_point_total.get('origin_actions', [])
                origin_actions_str = ", ".join(origin_actions)  # 以逗号分隔
                origin_call_chain = entry_point_total.get('origin_call_chain', [])
                origin_call_chain_str = " -> ".join(origin_call_chain)  # 以 '->'分隔
                origin_entry_method = origin_call_chain[0] if origin_call_chain else ''  # 新增：获取 origin_call_chain 的第一个元素
                
                # 添加记录
                record = {
                    'apk_name': apk_folder,
                    'sapcg_file': sapcg_file,
                    'sensitiveAPI': sensitiveAPI,
                    'call_chain': call_chain_str,
                    'entry_method': entry_method,  # 新增字段
                    'entry_point': entry_point,
                    'entry_point_actions': actions_str,
                    'origin_entry_point': origin_entry_point,
                    'origin_entry_point_actions': origin_actions_str,
                    'origin_call_chain': origin_call_chain_str,
                    'origin_entry_method': origin_entry_method,  # 新增字段
                }
                records.append(record)

    # 创建 DataFrame 并保存为总的 CSV 文件
    df = pd.DataFrame(
        records,
        columns=[
            'apk_name',
            'sapcg_file',
            'sensitiveAPI',
            'call_chain',
            'entry_method',               # 新增列
            'entry_point',
            'entry_point_actions',
            'origin_entry_point',
            'origin_entry_point_actions',
            'origin_call_chain',
            'origin_entry_method'         # 新增列
        ]
    )
    df = df.drop_duplicates()
    df.to_csv(output_csv_path, index=False, encoding='utf-8')
    print(f"处理完成，总的 CSV 文件已保存到：{output_csv_path}")


if __name__ == "__main__":
    # 输入和输出文件路径
    input_root_folder = '/media/wuyang/WD_BLACK/jiaming/iccbot/results/benign'  # 替换为 GPmalware 文件夹的路径
    output_csv_path = './data/all_apks_combined.csv'  # 替换为你希望的输出 CSV 文件路径

    process_all_apk_folders(input_root_folder, output_csv_path)

