import pandas as pd

def filter_csv_by_apk(input_csv_path_1, input_csv_path_2, output_csv_path):
    # 读取第一个 CSV 文件，提取 apk_name 列（过滤参考）
    df1 = pd.read_csv(input_csv_path_1, encoding='utf-8')
    apk_names = set(df1['apk_name'].apply(lambda x: f"{x}.apk"))  # 添加 .apk 后缀

    # 读取第二个 CSV 文件
    df2 = pd.read_csv(input_csv_path_2, sep=';', encoding='utf-8')

    # 筛选条件：apk 列的值在 apk_names 中
    filtered_df = df2[df2['apk'].isin(apk_names)]

    # 保存筛选后的数据
    filtered_df.to_csv(output_csv_path, index=False, sep=';', encoding='utf-8')
    print(f"筛选完成，处理后的 CSV 文件已保存到：{output_csv_path}")


def filter_csv_by_apk_and_callback(input_csv_path_1, input_csv_path_2, output_csv_path):
    # 读取第一个 CSV 文件
    df1 = pd.read_csv(input_csv_path_1, encoding='utf-8')
    apk_names = set(df1['apk_name'].apply(lambda x: f"{x}.apk"))  # 提取 apk_name，并添加 .apk 后缀
    call_chains = set(df1['call_chain'].dropna().str.split(" -> ").sum())  # 提取所有 call_chain 中的单个调用

    # 读取第二个 CSV 文件
    df2 = pd.read_csv(input_csv_path_2, sep=';', encoding='utf-8')

    # 筛选条件 1：apk 列的值在 apk_names 中
    filtered_df = df2[df2['apk'].isin(apk_names)]

    # 筛选条件 2：callback 列的值在 call_chain 列中出现
    filtered_df = filtered_df[filtered_df['callback'].isin(call_chains)]

    # 保存筛选后的数据
    filtered_df.to_csv(output_csv_path, index=False, sep=';', encoding='utf-8')
    print(f"筛选完成，处理后的 CSV 文件已保存到：{output_csv_path}")


if __name__ == "__main__":
    # 输入文件路径
    input_csv_path_1 = './data/all_apks_combined_merged.csv'  # 第一个 CSV 文件路径
    input_csv_path_2 = './backstage/api_21.csv'  # 第二个 CSV 文件路径
    # output_csv_path = './data/filtered_backstage_api.csv'  # 输出 CSV 文件路径
    output_csv_path = './data/filtered_backstage_api_callback.csv'  # 输出 CSV 文件路径

    # filter_csv_by_apk(input_csv_path_1, input_csv_path_2, output_csv_path)
    filter_csv_by_apk_and_callback(input_csv_path_1, input_csv_path_2, output_csv_path)
    
