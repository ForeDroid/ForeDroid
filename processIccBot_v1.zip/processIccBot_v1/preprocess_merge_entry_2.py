


import pandas as pd

def merge_columns(input_csv_path, output_csv_path):
    # 读取 CSV 文件
    df = pd.read_csv(input_csv_path, encoding='utf-8')
    
    # 删除不需要的列 'sapcg_file'
    if 'sapcg_file' in df.columns:
        df = df.drop(columns=['sapcg_file'])

    # 处理 entry_point 列：如果 origin_entry_point 不为空，则用 origin_entry_point，否则用 entry_point
    df['entry_point'] = df.apply(
        lambda row: row['origin_entry_point'] if pd.notnull(row['origin_entry_point']) and row['origin_entry_point'] else row['entry_point'],
        axis=1
    )

    # 处理 call_chain 列：如果 origin_call_chain 不为空，则将 origin_call_chain 和 call_chain 合并（origin_call_chain 在前）
    df['call_chain'] = df.apply(
        lambda row: f"{row['origin_call_chain']} -> {row['call_chain']}" if pd.notnull(row['origin_call_chain']) and row['origin_call_chain'] else row['call_chain'],
        axis=1
    )

    # 处理 entry_point_actions 列：如果 origin_entry_point_actions 不为空，则用 origin_entry_point_actions，否则用 entry_point_actions
    df['entry_point_actions'] = df.apply(
        lambda row: row['origin_entry_point_actions'] if pd.notnull(row['origin_entry_point_actions']) and row['origin_entry_point_actions'] else row['entry_point_actions'],
        axis=1
    )

        # 处理 entry_method 列：如果 origin_entry_method 不为空，则用 origin_entry_method，否则用 entry_method
    df['entry_method'] = df.apply(
        lambda row: row['origin_entry_method'] if pd.notnull(row['origin_entry_method']) and row['origin_entry_method'] else row['entry_method'],
        axis=1
    )

    # 删除处理后不再需要的列（如果需要删除 origin_entry_point、origin_call_chain、origin_entry_point_actions 等）
    df = df.drop(columns=['origin_entry_point', 'origin_call_chain', 'origin_entry_point_actions', 'origin_entry_method'])

    # 过滤只保留 entry_point 不为空的数据
    df = df[df['entry_point'].notnull() & (df['entry_point'] != '')]
    
    # 增加递增的 id 列
    df['id'] = range(1, len(df) + 1)
    
    # 保存处理后的文件
    df.to_csv(output_csv_path, index=False, encoding='utf-8')
    print(f"合并完成，处理后的 CSV 文件已保存到：{output_csv_path}")


def filter_action(input_csv_path, output_csv_path):
    df = pd.read_csv(input_csv_path, encoding='utf-8')
    df = df[df['entry_point_actions'].notnull() & (df['entry_point_actions'] != '')]
    df.to_csv(output_csv_path, index=False, encoding='utf-8')
    
if __name__ == "__main__":
    # 输入和输出文件路径
    input_csv_path = './data/all_apks_combined.csv'  # 输入文件路径
    output_csv_path = './data/all_apks_combined_merged_id.csv'  # 输出文件路径
    filter_action_csv_path = './data/all_apks_combined_merged_filtered_action.csv'  # 输出文件路径
    

    merge_columns(input_csv_path, output_csv_path)
    filter_action(output_csv_path, filter_action_csv_path)
