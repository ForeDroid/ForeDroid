import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import os
import sys

# Set proxy if necessary
os.environ['HTTP_PROXY'] = 'http://127.0.0.1:7890'

# Initialize the model
model = SentenceTransformer("all-MiniLM-L6-v2")

# Load your CSV file
csv_file = "/home/ming/work/iccbot/ICCBot/csv/data/all_apks_combined_merged.csv"  # Replace this with the actual CSV file path
df = pd.read_csv(csv_file)

# Add an incremental id column
df['id'] = range(1, len(df) + 1)  # Adds an 'id' column starting from 1

# Extract the call_chain column
call_chains = df['call_chain'].tolist()
ids = df['id'].tolist()  # Use the new id column for similarity matrix

# Encode the call chains
embeddings = model.encode(call_chains)
print(f"Shape of embeddings: {embeddings.shape}")

# Calculate cosine similarity
similarity_matrix = cosine_similarity(embeddings)

# Convert the similarity matrix into a DataFrame with IDs as row/column labels
similarity_df = pd.DataFrame(similarity_matrix, index=ids, columns=ids)

# Output the similarity matrix
print(similarity_df)

# Save the similarity matrix to a CSV file
similarity_df.to_csv("api_call_chain_similarity.csv", encoding="utf-8")

