import csv

# CSV文件路径
csv_file_path = 'data/with_descriptions-500.csv'

# 存储符合条件的id
valid_ids = []

# 条件检查函数
def check_valid_description(description):
    if not description.endswith('.') or description == "An error occurred. Either the engine you requested does not exist or there was another issue processing your request. If this issue persists please contact us through our help center at help.openai.com." or description == "Description generation failed":
        return False
    return True

# 读取CSV并筛选符合条件的id
with open(csv_file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        generated_description = row['generated_description']
        if not check_valid_description(generated_description):
            valid_ids.append(row['id'])

# 打印符合条件的id
print(valid_ids)
