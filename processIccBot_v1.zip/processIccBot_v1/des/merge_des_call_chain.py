import pandas as pd

# 当前CSV文件路径
csv_file_path = 'data/with_descriptions-500.csv'

# 另一个CSV文件路径（包含call_chain列）
another_csv_file_path = 'data/all_apks_combined_merged.csv'

# 读取当前CSV文件
df_current = pd.read_csv(csv_file_path)

# 读取另一个CSV文件的call_chain列
df_another = pd.read_csv(another_csv_file_path)

# 只取前501行的call_chain列
call_chain_list = df_another['call_chain'][:501]

# 将call_chain列合并到当前CSV的DataFrame中
df_current['call_chain'] = pd.Series(call_chain_list).reindex(df_current.index)

# 将合并后的数据保存到新的CSV文件
output_csv_path = 'data/merged_output.csv'
df_current.to_csv(output_csv_path, index=False)

print(f'Merged CSV file saved to {output_csv_path}')
