import os
import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
import undetected_chromedriver as uc

# 全局变量定义
CHROMEDRIVER_PATH = "/home/ming/work/ChatGLM3/codegee4/chromedriver_linux64/chromedriver"
OUTPUT_CSV_PATH = "./data/with_descriptions.csv"  # 输出的CSV文件路径

# 初始化 WebDriver并登录
def init_driver():
    options = uc.ChromeOptions()
    options.add_argument("--no-first-run")
    options.add_argument("--disable-blink-features=AutomationControlled")  # 隐藏自动化标识
    options.add_argument("--start-maximized")  # 最大化窗口
    options.ignore_local_proxy_environment_variables()
    driver = uc.Chrome(service=Service(CHROMEDRIVER_PATH), options=options)
    return driver

# 登录 ChatGPT 并保存 Cookies
def login_chatgpt(driver):
    driver.get("https://chat.openai.com/")
    input("请手动登录 ChatGPT 并按 Enter 键继续...")  # 等待手动登录完成
    print("登录成功，开始处理调用链")
    print("-" * 70)
    time.sleep(1)

# 发送问题并获取回答
def send_question_and_get_response(driver, question, is_first_question=False):
    try:
        # 输入框定位
        input_box = driver.find_element(By.CSS_SELECTOR, 'div.ProseMirror[contenteditable="true"]')

        # 输入问题，逐行输入并保留换行
        for line in question.splitlines():
            input_box.send_keys(line)
            input_box.send_keys(Keys.SHIFT + Keys.ENTER)  # 模拟 Shift + Enter 进行换行
        time.sleep(1)  # 添加短暂停顿，确保输入稳定
        previous_response_elements = driver.find_elements(By.CSS_SELECTOR, 'div.markdown.prose')
        previous_response = previous_response_elements[-1].text if previous_response_elements else ""

        input_box.send_keys(Keys.RETURN)  # 发送问题
        print(f"问题已发送: {question}")

        # 如果是第一次提问，忽略检查上一次的回复
        if is_first_question:
            print("第一次提问，直接等待回复...")
            for _ in range(20):  # 最多等待20秒
                response_elements = driver.find_elements(By.CSS_SELECTOR, 'div.markdown.prose')
                if response_elements:
                    latest_response = response_elements[-1].text  # 提取最后一个回复
                    print("ChatGPT 的最新回答：")
                    print(latest_response)
                    return latest_response
                time.sleep(1)  # 每秒检查一次

            print("未能获取到新的回复，超时退出。")
            return None

        # 获取当前页面上已有的最后一条回复
        time.sleep(5)  # 等待短暂时间，让页面加载部分内容

        # 等待新的回复加载
        for _ in range(20):  # 尝试最多等待20次（约20秒）
            response_elements = driver.find_elements(By.CSS_SELECTOR, 'div.markdown.prose')
            if response_elements:
                latest_response = response_elements[-1].text
                if latest_response != previous_response:  # 检测新回复是否与之前不同
                    print("ChatGPT 的最新回答：")
                    print(latest_response)
                    return latest_response
            time.sleep(1)  # 每秒检查一次

        # 如果超时仍未获取到新的回复
        print("未能获取到新的回复，超时退出。")
        return None
    except Exception as e:
        print(f"获取回答失败: {e}")
        return None




# 处理调用链并生成描述
def process_call_chains(driver, input_csv_path, output_csv_path):
    """Process API call chains and generate descriptions."""
    # Read the input CSV file
    df = pd.read_csv(input_csv_path)
    
    # Add an auto-incrementing 'id' column
    df["id"] = range(1, len(df) + 1)
    
    # Add a new column for generated descriptions
    df["generated_description"] = None
    count = 0
    
    # Iterate over each row in the DataFrame
    for index, row in df.iterrows():
        call_chain = row["call_chain"]  # Extract the call chain
        apk_name = row["apk_name"]      # Extract the APK name
        row_id = row["id"]              # Extract the row ID
        
        # Construct the prompt
        prompt = (
            "请根据以下API调用链生成一段简短且精炼的行为描述。描述主要使用名词和动词，保持一致的格式和术语。\n"
            "为了确保生成的描述适合后续的语义相似度计算，建议：\n"
            "统一动词和名词：始终使用指定的动词（如接收、监听、发送、处理）和名词（如意图、短信、消息）。\n"
            "避免同义词或不同表达方式：确保同类功能使用相同的动词和名词，避免使用不同的词语描述相同的功能。\n"
            "保持简洁明了：描述应尽量简短，突出关键操作，避免冗长和复杂的句子结构。\n"
            "综合相关函数的功能，避免重复或冗余的描述。回复不要换行，只要行为描述，不要具体函数信息\n"
            "回复用英文Only provide the behavioral description, without any additional explanation."
        )
        question = f"API call chain:\n{call_chain}"
        
        if count % 10 == 0:
            combined_question = prompt + "\n" + question
        else:
            combined_question = question
        
        # Determine if it's the first question
        is_first_question = (count == 0)
        
        # Send the question and get the response
        print(f"Processing APK: {apk_name}, ID: {row_id}")
        response = send_question_and_get_response(driver, combined_question, is_first_question)
        
        if response:
            # Save the generated description
            df.at[index, "generated_description"] = response
            count += 1
        else:
            print(f"Error: Failed to generate description for APK: {apk_name}, ID: {row_id}")
            df.at[index, "generated_description"] = "Description generation failed"
        
        # Save intermediate results to prevent data loss (append mode)
        df_to_save = df[["id", "call_chain", "generated_description"]]  # Include 'call_chain' in the output
        df_to_save.to_csv(output_csv_path, index=False, encoding="utf-8", mode='a', header=not os.path.exists(output_csv_path))  # Append mode
        
        print(f"Intermediate results saved to {output_csv_path}")
    
    print("All call chains have been processed!")


if __name__ == "__main__":
    INPUT_CSV_PATH = "./data/all_apks_combined_merged.csv"  # 输入的CSV文件路径
    OUTPUT_CSV_PATH = "./data/with_descriptions.csv"  # 输出的CSV文件路径

    driver = init_driver()
    try:
        login_chatgpt(driver)  # 手动登录一次
        process_call_chains(driver, INPUT_CSV_PATH, OUTPUT_CSV_PATH)  # 批量处理调用链
    finally:
        print("所有处理完成，程序退出。")
        driver.quit()  # 最后关闭浏览器
