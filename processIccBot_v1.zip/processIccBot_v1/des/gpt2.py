import os
import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import undetected_chromedriver as uc
import json
import re

# Global Variables
CHROMEDRIVER_PATH = "/home/ming/work/ChatGLM3/codegee4/chromedriver_linux64/chromedriver"
COOKIES_FILE_PATH = "./cookies.json"  # Path to save cookies
OUTPUT_CSV_PATH = "./data/with_descriptions.csv"  # Output CSV file path

def init_driver():
    """Initialize the Selenium WebDriver."""
    options = uc.ChromeOptions()
    options.add_argument("--no-first-run")
    options.add_argument("--disable-blink-features=AutomationControlled")  # Hide automation flags
    options.add_argument("--start-maximized")  # Maximize window
    options.ignore_local_proxy_environment_variables()
    driver = uc.Chrome(service=Service(CHROMEDRIVER_PATH), options=options)
    return driver

def save_cookies(driver, cookies_file_path):
    """Save browser cookies to a JSON file."""
    cookies = driver.get_cookies()
    with open(cookies_file_path, 'w') as f:
        json.dump(cookies, f)
    print(f"Cookies have been saved to {cookies_file_path}")

def load_cookies(driver, cookies_file_path):
    """Load browser cookies from a JSON file."""
    if os.path.exists(cookies_file_path):
        with open(cookies_file_path, 'r') as f:
            cookies = json.load(f)
        for cookie in cookies:
            # Remove 'sameSite' attribute if present to avoid issues
            if 'sameSite' in cookie:
                del cookie['sameSite']
            driver.add_cookie(cookie)
        print(f"Cookies loaded from {cookies_file_path}")
        return True
    else:
        print(f"Cookies file {cookies_file_path} does not exist.")
        return False

def login_chatgpt(driver, cookies_file_path):
    """Log into ChatGPT using cookies or manual login."""
    driver.get("https://chat.openai.com/")
    time.sleep(2)  # Wait for the page to load
    
    # Attempt to load cookies
    # if load_cookies(driver, cookies_file_path):
    #     driver.refresh()
    #     try:
    #         # Replace with a selector that uniquely identifies a logged-in state
    #         WebDriverWait(driver, 10).until(
    #             EC.presence_of_element_located((By.CSS_SELECTOR, 'div.some-logged-in-element'))
    #         )
    #         print("Logged in using cookies.")
    #         return
    #     except:
    #         print("Cookies are invalid or expired. Proceeding to manual login.")
    
    # Perform manual login
    input("Please manually log in to ChatGPT and press Enter here to continue...")
    print("Login successful. Saving cookies.")
    save_cookies(driver, cookies_file_path)

def send_question_and_get_response(driver, question, is_first_question=False):
    """Send a question to ChatGPT and retrieve the latest response."""
    try:
        # Locate the input box
        input_box = driver.find_element(By.CSS_SELECTOR, 'div.ProseMirror[contenteditable="true"]')
        
        # Enter the question line by line
        for line in question.splitlines():
            input_box.send_keys(line)
            input_box.send_keys(Keys.SHIFT + Keys.ENTER)  # Preserve line breaks
        time.sleep(1)  # Wait to ensure stability
        input_box.send_keys(Keys.RETURN)  # Send the question
        print(f"Question sent: {question}")
        # Get the last response before sending the new question
        response_elements = driver.find_elements(By.CSS_SELECTOR, 'div.markdown.prose')
        
        previous_response = response_elements[-1].text if response_elements else ""
            
        time.sleep(2)
        if is_first_question:
            print("First question being processed. Waiting for response...")
            wait_time = 20  # Maximum wait time in seconds
            for _ in range(wait_time):
                response_elements = driver.find_elements(By.CSS_SELECTOR, 'div.markdown.prose')
                if response_elements:
                    latest_response = response_elements[-1].text
                    print("ChatGPT's response:")
                    print(latest_response)
                    return latest_response
                time.sleep(1)
        else:
            # Wait for a new response that differs from the previous one
            wait_time = 20  # Maximum wait time in seconds
            for num in range(wait_time):
                response_elements = driver.find_elements(By.CSS_SELECTOR, 'div.markdown.prose')
                if response_elements:
                    latest_response = response_elements[-1].text
                    if latest_response != previous_response  and latest_response.endswith('.'):
                        print("ChatGPT's new response:")
                        print(latest_response)
                        return latest_response
                time.sleep(1)
                if num == 18:
                    print("pause")
        
        # Timeout handling
        print("Failed to retrieve a new response within the wait time.")
        return None
    except Exception as e:
        print(f"Failed to get response: {e}")
        return None

def process_call_chains(driver, input_csv_path, output_csv_path):
    """Process API call chains and generate descriptions."""
    # Read the input CSV file
    df = pd.read_csv(input_csv_path)
    
    
    # Add a new column for generated descriptions
    df["generated_description"] = None
    count = 0
    
    # Iterate over each row in the DataFrame
    for index, row in df.iterrows():
        if index <= 500:
            continue
        call_chain = row["call_chain"]  # Extract the call chain
        apk_name = row["apk_name"]      # Extract the APK name
        row_id = row["id"]              # Extract the row ID
        
        # Construct the prompt
        prompt = (
            "请根据以下API调用链生成一段简短且精炼的行为描述。描述主要使用名词和动词，保持一致的格式和术语。\n"
            "为了确保生成的描述适合后续的语义相似度计算，建议：\n"
            "统一动词和名词：始终使用指定的动词（如接收、监听、发送、处理）和名词（如意图、短信、消息）。\n"
            "避免同义词或不同表达方式：确保同类功能使用相同的动词和名词，避免使用不同的词语描述相同的功能。\n"
            "保持简洁明了：描述应尽量简短，突出关键操作，避免冗长和复杂的句子结构。\n"
            "综合相关函数的功能，避免重复或冗余的描述。回复不要换行，只要行为描述，不要具体函数信息\n"
            "回复用英文Only provide the behavioral description, without any additional explanation."
        )
        question = f"API call chain:\n{call_chain}"
        
        if count % 10 == 0:
            combined_question = prompt + "\n" + question
        else:
            combined_question = question
        
        # Determine if it's the first question
        is_first_question = (count == 0)
        
        # Send the question and get the response
        print(f"Processing call chain: {call_chain}")
        response = send_question_and_get_response(driver, combined_question, is_first_question)
        
        if response:
            # Save the generated description
            row_to_append = {"call_chain": call_chain, "generated_description": response, "id":row_id}
            pd.DataFrame([row_to_append]).to_csv(output_csv_path, header=0, index=False, mode='a', encoding="utf-8")
            print(f"Appended response for APK: {apk_name}, ID: {row_id}")
            count += 1
        else:
            print(f"Error: Failed to generate description for APK: {apk_name}")
            row_to_append = {"call_chain": call_chain, "generated_description": "Description generation failed", "id":row_id}
            pd.DataFrame([row_to_append]).to_csv(output_csv_path, header=0, index=False, mode='a', encoding="utf-8")
            print(f"Error: Failed to generate description for APK: {apk_name}, ID: {row_id}")
        
        # Save intermediate results to prevent data loss
        # df[["call_chain", "generated_description"]].to_csv(output_csv_path, mode='a', header=not pd.io.common.file_exists(output_csv_path), index=False, encoding="utf-8")
        # print(f"Intermediate results saved to {output_csv_path}")
    
    print("All call chains have been processed!")
    
def extract_questions_from_page(driver):
    """Extract questions from the page and clean the text."""
    try:
        # Find all question elements (both with or without Chinese prefix)
        question_elements = driver.find_elements(By.CSS_SELECTOR, 'div.whitespace-pre-wrap')
        
        # Extract the text and process it
        questions = []
        for question_element in question_elements:
            question_text = question_element.text.strip()
            
            # Check for 'API call chain:' and extract everything after it
            match = re.search(r"API call chain:\s*(.*)", question_text)
            if match:
                # Extract API call chain after the prefix
                question = match.group(1).strip()
                questions.append(question)
        
        return questions
    except Exception as e:
        print(f"Error extracting questions: {e}")
        return []

def save_questions_and_answers_to_csv_with_pandas(driver, output_csv_path):
    """Extract all questions and their corresponding answers from the page and save to a CSV file using pandas."""
    try:
        # Extract questions and answers from the page
        questions = extract_questions_from_page(driver)
        
        # Find all answer elements
        answer_elements = driver.find_elements(By.CSS_SELECTOR, 'div.markdown.prose')
        question_count = len(questions)
        answer_count = len(answer_elements)
        
         # If answers are fewer than questions, we can append a placeholder for unanswered questions
        if question_count > answer_count:
            answer_elements.extend(['No answer'] * (question_count - answer_count))
        
        # If there are more answers than questions, we ignore the extra answers
        if answer_count > question_count:
            answer_elements = answer_elements[:question_count]
        
        
        # Ensure that the number of questions matches the number of answers
        if len(questions) == len(answer_elements):
            answers = [answer.text.strip() for answer in answer_elements]
            
            # Create a DataFrame
            df = pd.DataFrame({
                'Question': questions,
                'Answer': answers
            })
            
            # Save the DataFrame to a CSV file
            df.to_csv(output_csv_path, index=False, encoding='utf-8')
            print(f"All questions and answers have been saved to {output_csv_path}")
        else:
            print("The number of questions does not match the number of answers.")
    
    except Exception as e:
        print(f"An error occurred while saving questions and answers to CSV: {e}")


if __name__ == "__main__":
    INPUT_CSV_PATH = "./data/all_apks_combined_merged_id.csv"  # Input CSV file path
    OUTPUT_CSV_PATH = "./data/with_descriptions_512.csv"        # Output CSV file path
    
    driver = init_driver()
    try:
        login_chatgpt(driver, COOKIES_FILE_PATH)  # Attempt to load cookies or perform manual login
        # save_questions_and_answers_to_csv_with_pandas(driver, "./data/descriptions_from_web")
        process_call_chains(driver, INPUT_CSV_PATH, OUTPUT_CSV_PATH)  # Batch process call chains
    finally:
        print("All processing completed. Exiting the program.")
        driver.quit()  # Finally, close the browser
